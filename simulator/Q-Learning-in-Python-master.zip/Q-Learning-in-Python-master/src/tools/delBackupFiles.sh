#!/bin/bash
find ./ -name '*~' -exec rm '{}' \; -print -or -name ".*~" -exec rm {} \; -print